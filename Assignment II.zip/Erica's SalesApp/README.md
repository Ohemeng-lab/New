# Daily Sales Tracker

A simple Flask web app for recording a small shop's daily sales.

## Requirements
- Python 3.9+
- Flask (`pip install flask`)

## Run it
```bash
pip install flask
python app.py
```
Then open **http://127.0.0.1:5000** in your browser.

## Project structure
```
sales-app/
├── app.py              # Flask backend (routes + sales logic)
├── templates/
│   └── index.html      # page template (Jinja2)
└── static/
    └── style.css        # styling
```

## How it works
- Sales are stored in memory as a list of dictionaries (`sales`), so the
  list is fresh each time the server restarts — matching the brief's
  "during the session" requirement.
- Submitting the form sends a `POST` to `/add`, which validates the input
  and appends a new sale dictionary to the list.
- Each row's delete button sends a `POST` to `/delete/<id>` to remove that
  one entry.
- The grand total is recalculated with a loop every time the page loads.
