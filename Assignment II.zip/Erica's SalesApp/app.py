"""
Daily Sales Tracker - Flask Backend
Assignment II: Simple Sales Recording Web Application

This backend uses the core Python concepts covered in class:
  - variables        -> next_id, grand_total, product, quantity, price ...
  - data types        -> str (product), int (quantity), float (price/total)
  - lists             -> `sales` holds every sale recorded this session
  - dictionaries      -> each individual sale is stored as a dictionary
  - control flow      -> if/else validation, for loops, list comprehension
"""

from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# ---------------------------------------------------------------------------
# In-memory "database" for the current session.
# `sales` is a list of dictionaries. Because there is no real database,
# everything resets when the server restarts - which matches the brief
# ("display of all sales entered during the session").
# ---------------------------------------------------------------------------
sales = []
next_id = 1  # simple counter so every sale can be found again for deletion


def calculate_grand_total(sales_list):
    """Add up every sale's total using a for loop (control flow)."""
    grand_total = 0.0
    for sale in sales_list:
        grand_total += sale["total"]
    return grand_total


@app.route("/")
def index():
    """Show the entry form plus every sale recorded so far."""
    grand_total = calculate_grand_total(sales)
    return render_template("index.html", sales=sales, grand_total=grand_total)


@app.route("/add", methods=["POST"])
def add_sale():
    """Read the submitted form, validate it, and store a new sale."""
    global next_id

    product = request.form.get("product", "").strip()
    quantity_raw = request.form.get("quantity", "")
    price_raw = request.form.get("price", "")

    # --- Validation (control flow) ---------------------------------------
    # Only accept the entry if every field is present and numeric.
    if product and quantity_raw and price_raw:
        try:
            quantity = int(quantity_raw)
            price = float(price_raw)
        except ValueError:
            quantity = price = None  # non-numeric input -> ignore silently

        if quantity is not None and price is not None and quantity > 0 and price > 0:
            sale = {
                "id": next_id,
                "product": product,
                "quantity": quantity,
                "price": price,
                "total": quantity * price,
            }
            sales.append(sale)
            next_id += 1

    return redirect(url_for("index"))


@app.route("/delete/<int:sale_id>", methods=["POST"])
def delete_sale(sale_id):
    """Remove one sale by id (bonus feature)."""
    global sales
    sales = [sale for sale in sales if sale["id"] != sale_id]
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
